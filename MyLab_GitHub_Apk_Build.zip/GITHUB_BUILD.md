# MyLab - GitHub से APK बनाना

1. इस पूरे project को GitHub repository में upload करें.
2. Repository में **Actions** खोलें.
3. **Build MyLab APK** workflow चुनें.
4. **Run workflow** दबाएँ.
5. Build पूरा होने पर workflow run खोलें.
6. नीचे **Artifacts** में `MyLab-debug-apk` डाउनलोड करें.
7. ZIP खोलकर APK को Vivo T2x में install करें.

अगर Actions disabled दिखे, repository की Settings > Actions में GitHub Actions enable करें.
