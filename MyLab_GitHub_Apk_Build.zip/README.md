# My Lab — Expanded LIMS Android Build

इस build में पहले वाले demo से आगे ये modules जोड़े गए हैं:

- Local persistent data store (patients, tests, orders, samples, results, settings)
- Patient registration with doctor/referral/address
- Test catalogue with sample type, TAT, unit and reference range
- Order creation + test selection + discount + paid/due billing
- Sample tracking: Collected → Received → Processing → Completed / Rejected
- Result entry and pathologist approval state
- PDF laboratory report generation using Android PdfDocument
- Lab profile/settings used by reports
- Dashboard counts and revenue
- Doctors/referrals module placeholder
- Backup/restore and external integrations के लिए integration points
- Role-based production architecture का आधार

## Production notes
यह source एक complete functional Android foundation है, लेकिन कोई lab app बिना
अपने server, user accounts, privacy/security policy, analyzer protocols, barcode hardware,
WhatsApp/SMS provider और cloud backup credentials के universally production-ready नहीं हो सकता।
इन external systems के लिए provider/API credentials और machine protocol अलग-अलग होते हैं।

## Run
Android Studio में folder खोलें → Gradle Sync → Run.
