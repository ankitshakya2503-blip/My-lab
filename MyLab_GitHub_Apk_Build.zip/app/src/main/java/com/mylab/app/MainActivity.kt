package com.mylab.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{MaterialTheme(colorScheme=lightColorScheme(primary=androidx.compose.ui.graphics.Color(0xFF1565C0))){MyLabApp()}}}
}

@Composable fun MyLabApp(){
 val context=LocalContext.current
 val store=remember{AppStore(context)}
 var login by remember{mutableStateOf(false)}
 var page by remember{mutableStateOf("home")}
 var refresh by remember{mutableIntStateOf(0)}
 fun reload(){refresh++}
 if(!login) Login{login=true} else when(page){
  "home"->Home(store,reload){page=it}
  "patients"->Patients(store,reload){page="home"}
  "tests"->Tests(store,reload){page="home"}
  "orders"->Orders(store,reload){page="home"}
  "samples"->Samples(store,reload){page="home"}
  "results"->Results(store,reload){page="home"}
  "reports"->Reports(store,reload){page="home"}
  "doctors"->Doctors(store,reload){page="home"}
  "settings"->Settings(store,reload){page="home"}
 }
}

@Composable fun Login(done:()->Unit){
 var u by remember{mutableStateOf("")}; var p by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
  Text("My Lab",fontSize=38.sp);Text("Laboratory Management System")
  Spacer(Modifier.height(28.dp));Field("Username",u){u=it};Field("Password",p){p=it}
  Button(done,Modifier.fillMaxWidth()){Text("Login")}
 }
}
@Composable fun Home(s:AppStore,r:()->Unit,go:(String)->Unit){
 val cards=listOf("Patients" to s.patients.size,"Tests" to s.tests.size,"Orders" to s.orders.size,"Samples" to s.samples.size,"Pending Reports" to s.results.count{!it.approved},"Revenue" to "₹"+s.orders.sumOf{it.total})
 Column(Modifier.fillMaxSize().padding(16.dp)){
  Text("My Lab",style=MaterialTheme.typography.headlineLarge);Text("Laboratory Dashboard")
  Spacer(Modifier.height(14.dp))
  LazyVerticalGrid(GridCells.Fixed(2),Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
   gridItems(cards){(a,b)->Card{Column(Modifier.padding(16.dp)){Text(a);Text("$b",fontSize=25.sp)}}}
  }
  listOf("New Patient" to "patients","Create Order / Billing" to "orders","Sample Tracking" to "samples","Result Entry / Approval" to "results","Reports / PDF" to "reports","Tests & Packages" to "tests","Doctors / Referrals" to "doctors","Lab Settings / Backup" to "settings").forEach{(x,y)->OutlinedButton({go(y)},Modifier.fillMaxWidth()){Text(x)}}
 }
}

@Composable fun Patients(s:AppStore,r:()->Unit,back:()->Unit){
 var name by remember{mutableStateOf("")};var mob by remember{mutableStateOf("")};var age by remember{mutableStateOf("")};var gender by remember{mutableStateOf("Male")};var addr by remember{mutableStateOf("")};var doc by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().padding(16.dp)){
  Header("Patient Registration",back)
  LazyColumn(Modifier.weight(1f)){
   item{Field("Name *",name){name=it};Field("Mobile",mob){mob=it};Field("Age",age){age=it};Text("Gender");Row{listOf("Male","Female","Other").forEach{x->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(gender==x,{gender=x});Text(x)}}};Field("Address",addr){addr=it};Field("Referring Doctor",doc){doc=it}
   Button({if(name.isNotBlank()){s.patients=s.patients.toMutableList().apply{add(Patient(s.newId("PAT"),name,mob,age,gender,addr,doc))};name="";mob="";age="";addr="";doc="";r()}},Modifier.fillMaxWidth()){Text("Save Patient")};Text("Patients",style=MaterialTheme.typography.titleLarge)}
   items(s.patients){p->Card(Modifier.fillMaxWidth().padding(3.dp)){Column(Modifier.padding(12.dp)){Text("${p.id} • ${p.name}",style=MaterialTheme.typography.titleMedium);Text("${p.mobile} • ${p.age} • ${p.gender}");Text(p.doctor)}}}
  }
 }
}

@Composable fun Tests(s:AppStore,r:()->Unit,back:()->Unit){
 var name by remember{mutableStateOf("")};var price by remember{mutableStateOf("")};var sample by remember{mutableStateOf("Serum")};var tat by remember{mutableStateOf("6 Hours")}
 Column(Modifier.fillMaxSize().padding(16.dp)){Header("Tests & Packages",back)
  Field("Test Name",name){name=it};Field("Price",price){price=it};Field("Sample Type",sample){sample=it};Field("TAT",tat){tat=it}
  Button({if(name.isNotBlank()){s.tests=s.tests.toMutableList().apply{add(LabTest(s.newId("TST"),name,price.toIntOrNull()?:0,sample,tat))};name="";price="";r()}},Modifier.fillMaxWidth()){Text("Add Test")}
  LazyColumn{items(s.tests){t->Card(Modifier.fillMaxWidth().padding(3.dp)){Row(Modifier.padding(12.dp)){Column(Modifier.weight(1f)){Text(t.name);Text("${t.sample} • ${t.tat}")};Text("₹${t.price}")}}}}
 }
}

@Composable fun Orders(s:AppStore,r:()->Unit,back:()->Unit){
 var pid by remember{mutableStateOf("")};var selected by remember{mutableStateOf(setOf<String>())};var discount by remember{mutableStateOf("0")};var paid by remember{mutableStateOf(false)}
 val sub=s.tests.filter{it.id in selected}.sumOf{it.price};val d=discount.toIntOrNull()?:0;val total=(sub-d).coerceAtLeast(0)
 Column(Modifier.fillMaxSize().padding(16.dp)){Header("Order & Billing",back);Field("Patient ID",pid){pid=it};Field("Discount ₹",discount){discount=it}
 LazyColumn(Modifier.weight(1f)){items(s.tests){t->Row(verticalAlignment=Alignment.CenterVertically){Checkbox(t.id in selected,{selected=if(it)selected+t.id else selected-t.id});Text(t.name,Modifier.weight(1f));Text("₹${t.price}")}}}
 Text("Subtotal ₹$sub");Text("Total ₹$total",style=MaterialTheme.typography.headlineSmall)
 Row(verticalAlignment=Alignment.CenterVertically){Checkbox(paid,{paid=it});Text("Payment received")}
 Button({if(pid.isNotBlank()&&selected.isNotEmpty()){s.orders=s.orders.toMutableList().apply{add(Order(s.newId("ORD"),pid,selected.toList(),sub,d,total,if(paid)"PAID" else "DUE"))};r()}},Modifier.fillMaxWidth()){Text("Create Order & Invoice")}
 }
}

@Composable fun Samples(s:AppStore,r:()->Unit,back:()->Unit){
 var oid by remember{mutableStateOf("")};var status by remember{mutableStateOf("Collected")}
 Column(Modifier.fillMaxSize().padding(16.dp)){Header("Sample Tracking / Barcode",back);Field("Order ID",oid){oid=it}
 listOf("Collected","Received","Processing","Completed","Rejected").forEach{x->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(status==x,{status=x});Text(x)}}
 Button({if(oid.isNotBlank()){val old=s.samples.indexOfFirst{it.orderId==oid};val l=s.samples.toMutableList();val sm=Sample(if(old>=0)l[old].id else s.newId("SMP"),oid,status);if(old>=0)l[old]=sm else l.add(sm);s.samples=l;r()}},Modifier.fillMaxWidth()){Text("Save Sample Status")}
 LazyColumn{items(s.samples){x->Card(Modifier.fillMaxWidth().padding(3.dp)){Column(Modifier.padding(12.dp)){Text(x.id);Text("Order: ${x.orderId}");Text("Status: ${x.status}")}}}}
 }
}

@Composable fun Results(s:AppStore,r:()->Unit,back:()->Unit){
 var oid by remember{mutableStateOf("")};var tid by remember{mutableStateOf("")};var value by remember{mutableStateOf("")};var remark by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().padding(16.dp)){Header("Result Entry & Approval",back);Field("Order ID",oid){oid=it};Field("Test ID",tid){tid=it};Field("Result",value){value=it};Field("Remarks",remark){remark=it}
 Row{Button({if(oid.isNotBlank()&&tid.isNotBlank()){s.results=s.results.toMutableList().apply{add(Result(oid,tid,value,remark,false))};r()}},Modifier.weight(1f)){Text("Save")};Spacer(Modifier.width(8.dp));Button({val i=s.results.indexOfLast{it.orderId==oid&&it.testId==tid};if(i>=0){val l=s.results.toMutableList();l[i]=l[i].copy(approved=true);s.results=l;r()}},Modifier.weight(1f)){Text("Approve")}}
 LazyColumn{items(s.results){x->Card(Modifier.fillMaxWidth().padding(3.dp)){Text("${x.orderId} • ${x.testId} • ${x.value} • ${if(x.approved)"APPROVED" else "PENDING"}",Modifier.padding(12.dp))}}}
 }
}

@Composable fun Reports(s:AppStore,r:()->Unit,back:()->Unit){
 val ctx=LocalContext.current;var msg by remember{mutableStateOf("")};var oid by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().padding(16.dp)){Header("Reports / PDF",back);Field("Order ID",oid){oid=it};Button({
  val o=s.orders.firstOrNull{it.id==oid};val p=o?.let{x->s.patients.firstOrNull{it.id==x.patientId}}
  if(o!=null&&p!=null){val f=PdfReport.create(ctx,s.settings,p,o,s.tests,s.results);msg="PDF तैयार: ${f.name}";try{ctx.startActivity(Intent(Intent.ACTION_VIEW).apply{setDataAndType(Uri.fromFile(f),"application/pdf");addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)})}catch(_:Exception){}}
 },Modifier.fillMaxWidth()){Text("Generate PDF Report")}
 Text(msg)
 LazyColumn{items(s.orders){o->Card(Modifier.fillMaxWidth().padding(3.dp)){Column(Modifier.padding(12.dp)){Text(o.id);Text("Patient: ${o.patientId} • Total ₹${o.total} • ${o.paymentStatus}")}}}}
 }
}

@Composable fun Doctors(s:AppStore,r:()->Unit,back:()->Unit){
 var name by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().padding(16.dp)){Header("Doctors / Referrals",back);Field("Doctor Name",name){name=it};Field("Phone",phone){phone=it};Button({},Modifier.fillMaxWidth()){Text("Save Doctor")};Text("Referral management module ready for server/API connection.",Modifier.padding(12.dp))}
}

@Composable fun Settings(s:AppStore,r:()->Unit,back:()->Unit){
 var lab by remember{mutableStateOf(s.settings.labName)};var addr by remember{mutableStateOf(s.settings.address)};var phone by remember{mutableStateOf(s.settings.phone)};var path by remember{mutableStateOf(s.settings.pathologist)};var reg by remember{mutableStateOf(s.settings.registrationNo)}
 Column(Modifier.fillMaxSize().padding(16.dp)){Header("Lab Settings",back);Field("Lab Name",lab){lab=it};Field("Address",addr){addr=it};Field("Phone",phone){phone=it};Field("Pathologist",path){path=it};Field("Registration No.",reg){reg=it}
 Button({s.settings=LabSettings(lab,addr,phone,s.settings.email,path,reg);r()},Modifier.fillMaxWidth()){Text("Save Lab Settings")}
 Spacer(Modifier.height(12.dp));Text("Backup / Restore",style=MaterialTheme.typography.titleLarge)
 Button({/* export hook */},Modifier.fillMaxWidth()){Text("Backup Data")};OutlinedButton({/* import hook */},Modifier.fillMaxWidth()){Text("Restore Data")}
 Text("Security, cloud backup, analyzer connectivity and WhatsApp/SMS require the lab's own accounts/server credentials.",Modifier.padding(top=12.dp))
 }
}

@Composable fun Header(title:String,back:()->Unit){Row(verticalAlignment=Alignment.CenterVertically){Text(title,style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.weight(1f));TextButton(back){Text("Back")}}}
@Composable fun Field(label:String,value:String,onChange:(String)->Unit){OutlinedTextField(value,onChange,label={Text(label)},modifier=Modifier.fillMaxWidth().padding(vertical=4.dp),singleLine=true)}
