package com.mylab.app

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

class AppStore(context:Context) {
    private val prefs=context.getSharedPreferences("mylab_data",Context.MODE_PRIVATE)
    private val gson=Gson()

    var patients:MutableList<Patient>
        get()=read("patients",object:TypeToken<MutableList<Patient>>(){}.type) ?: mutableListOf()
        set(v){write("patients",v)}
    var tests:MutableList<LabTest>
        get()=read("tests",object:TypeToken<MutableList<LabTest>>(){}.type) ?: defaultTests()
        set(v){write("tests",v)}
    var orders:MutableList<Order>
        get()=read("orders",object:TypeToken<MutableList<Order>>(){}.type) ?: mutableListOf()
        set(v){write("orders",v)}
    var samples:MutableList<Sample>
        get()=read("samples",object:TypeToken<MutableList<Sample>>(){}.type) ?: mutableListOf()
        set(v){write("samples",v)}
    var results:MutableList<Result>
        get()=read("results",object:TypeToken<MutableList<Result>>(){}.type) ?: mutableListOf()
        set(v){write("results",v)}
    var settings:LabSettings
        get()=read("settings",object:TypeToken<LabSettings>(){}.type) ?: LabSettings()
        set(v){write("settings",v)}

    private fun <T> read(k:String,t:java.lang.reflect.Type):T? =
        prefs.getString(k,null)?.let{gson.fromJson<T>(it,t)}
    private fun write(k:String,v:Any){prefs.edit().putString(k,gson.toJson(v)).apply()}
    fun newId(prefix:String)=prefix+"-"+UUID.randomUUID().toString().take(8).uppercase()
    fun clearAll(){prefs.edit().clear().apply()}

    private fun defaultTests()=mutableListOf(
        LabTest("CBC","Complete Blood Count",350,"EDTA Blood","4 Hours","Multiple","See report"),
        LabTest("LFT","Liver Function Test",700,"Serum","6 Hours","Multiple","See report"),
        LabTest("KFT","Kidney Function Test",650,"Serum","6 Hours","Multiple","See report"),
        LabTest("HBA1C","HbA1c",450,"EDTA Blood","4 Hours","%","4.0–5.6"),
        LabTest("LIPID","Lipid Profile",600,"Serum","6 Hours","mg/dL","See report"),
        LabTest("THYROID","Thyroid Profile",700,"Serum","8 Hours","Multiple","See report"),
        LabTest("URINE","Urine Routine",200,"Urine","4 Hours","Multiple","See report")
    )
}
