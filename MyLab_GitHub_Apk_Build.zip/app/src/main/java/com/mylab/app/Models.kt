package com.mylab.app

data class Patient(
    val id:String, val name:String, val mobile:String, val age:String, val gender:String,
    val address:String="", val doctor:String="", val createdAt:Long=System.currentTimeMillis()
)
data class LabTest(
    val id:String, val name:String, val price:Int, val sample:String, val tat:String,
    val unit:String="", val referenceRange:String=""
)
data class Order(
    val id:String, val patientId:String, val testIds:List<String>, val subtotal:Int,
    val discount:Int, val total:Int, val paymentStatus:String, val createdAt:Long=System.currentTimeMillis()
)
data class Sample(val id:String,val orderId:String,val status:String,val collectedBy:String="")
data class Result(val orderId:String,val testId:String,val value:String,val remarks:String="",val approved:Boolean=false)
data class LabSettings(
    val labName:String="My Lab", val address:String="Your Lab Address",
    val phone:String="", val email:String="", val pathologist:String="",
    val registrationNo:String=""
)
